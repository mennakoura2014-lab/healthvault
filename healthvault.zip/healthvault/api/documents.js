// api/documents.js
// Vercel serverless function — handles document CRUD
// Storage: Vercel Blob (configure BLOB_READ_WRITE_TOKEN in env vars)
// For a quick demo without Blob, falls back to in-memory store (resets per cold start)

import { v4 as uuidv4 } from 'uuid';

// ── In-memory fallback store (replace with DB/Blob for persistence) ──────────
const store = globalThis.__hv_store ?? (globalThis.__hv_store = {
  documents: [
    {
      id: '1', name: 'Discharge Summary — Royal Berkshire Hospital',
      category: 'discharge', date: '2025-11-18', size: '1.2 MB',
      notes: 'Admitted for chest pain. ECG normal. Discharged with follow-up in 4 weeks.',
      url: null, mimetype: null
    },
    {
      id: '2', name: 'HbA1c & Lipid Panel Results',
      category: 'lab', date: '2026-01-07', size: '420 KB',
      notes: 'HbA1c 7.2%, LDL 2.8 mmol/L, eGFR 74 mL/min.',
      url: null, mimetype: null
    },
    {
      id: '3', name: 'Metformin 500mg Prescription',
      category: 'prescription', date: '2026-02-20', size: '180 KB',
      notes: '90-day supply. Twice daily with meals.',
      url: null, mimetype: null
    },
    {
      id: '4', name: 'Chest X-Ray Report',
      category: 'imaging', date: '2026-03-14', size: '2.1 MB',
      notes: 'No acute cardiopulmonary process identified.',
      url: null, mimetype: null
    }
  ],
  medications: [
    { id: 'm1', name: 'Metformin', dose: '500mg', frequency: 'Twice daily', status: 'active', refillDue: true },
    { id: 'm2', name: 'Ramipril', dose: '5mg', frequency: 'Once daily', status: 'active', refillDue: false },
    { id: 'm3', name: 'Atorvastatin', dose: '20mg', frequency: 'At night', status: 'active', refillDue: false },
    { id: 'm4', name: 'Aspirin', dose: '75mg', frequency: 'Once daily', status: 'past', refillDue: false }
  ]
});

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

// ── Parse multipart form data without heavy deps ──────────────────────────────
async function parseMultipart(req) {
  return new Promise((resolve, reject) => {
    const Busboy = require('busboy');
    const bb = Busboy({ headers: req.headers, limits: { fileSize: 50 * 1024 * 1024 } });
    const fields = {};
    const files = [];

    bb.on('field', (name, val) => { fields[name] = val; });
    bb.on('file', (name, stream, info) => {
      const chunks = [];
      stream.on('data', d => chunks.push(d));
      stream.on('end', () => {
        files.push({ fieldname: name, originalname: info.filename, mimetype: info.mimeType, buffer: Buffer.concat(chunks) });
      });
    });
    bb.on('finish', () => resolve({ fields, files }));
    bb.on('error', reject);
    req.pipe(bb);
  });
}

function guessCategory(filename, mimeType) {
  const n = (filename || '').toLowerCase();
  const m = (mimeType || '').toLowerCase();
  if (n.includes('discharge') || n.includes('summary') || n.includes('report')) return 'discharge';
  if (n.includes('lab') || n.includes('result') || n.includes('blood') || n.includes('hba') || n.includes('panel')) return 'lab';
  if (n.includes('rx') || n.includes('prescription') || n.includes('med') || n.includes('tablet') || n.includes('capsule')) return 'prescription';
  if (n.includes('xray') || n.includes('x-ray') || n.includes('ct') || n.includes('mri') || n.includes('scan') || n.includes('imaging') || m.includes('dicom')) return 'imaging';
  return 'other';
}

function fmtSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return Math.round(bytes / 1024) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

// ── Main handler ──────────────────────────────────────────────────────────────
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(200).end();

  const { action } = req.query;

  // GET /api/documents?action=list
  if (req.method === 'GET' && action === 'list') {
    return res.json({ documents: store.documents, medications: store.medications });
  }

  // POST /api/documents?action=upload
  if (req.method === 'POST' && action === 'upload') {
    try {
      const { fields, files } = await parseMultipart(req);
      if (!files.length) return res.status(400).json({ error: 'No file provided' });

      const results = files.map(file => {
        // In production: upload file.buffer to Vercel Blob / S3 here
        // const { url } = await put(file.originalname, file.buffer, { access: 'public' });
        const category = fields.category || guessCategory(file.originalname, file.mimetype);
        const doc = {
          id: uuidv4(),
          name: (file.originalname || 'Unnamed').replace(/\.[^.]+$/, ''),
          category,
          date: fields.date || new Date().toISOString().split('T')[0],
          size: fmtSize(file.buffer.length),
          notes: fields.notes || '',
          url: null, // url from Blob storage goes here
          mimetype: file.mimetype,
          originalname: file.originalname
        };
        store.documents.unshift(doc);
        return doc;
      });

      return res.json({ success: true, documents: results });
    } catch (e) {
      console.error(e);
      return res.status(500).json({ error: e.message });
    }
  }

  // DELETE /api/documents?action=delete&id=xxx
  if (req.method === 'DELETE' && action === 'delete') {
    const { id } = req.query;
    const idx = store.documents.findIndex(d => d.id === id);
    if (idx === -1) return res.status(404).json({ error: 'Not found' });
    store.documents.splice(idx, 1);
    return res.json({ success: true });
  }

  // POST /api/documents?action=add-medication
  if (req.method === 'POST' && action === 'add-medication') {
    const body = await new Promise(resolve => {
      let data = '';
      req.on('data', c => (data += c));
      req.on('end', () => resolve(JSON.parse(data || '{}')));
    });
    const med = { id: uuidv4(), ...body, refillDue: false };
    store.medications.unshift(med);
    return res.json({ success: true, medication: med });
  }

  // DELETE /api/documents?action=delete-medication&id=xxx
  if (req.method === 'DELETE' && action === 'delete-medication') {
    const { id } = req.query;
    const idx = store.medications.findIndex(m => m.id === id);
    if (idx !== -1) store.medications.splice(idx, 1);
    return res.json({ success: true });
  }

  return res.status(405).json({ error: 'Method not allowed' });
}

export const config = { api: { bodyParser: false } };

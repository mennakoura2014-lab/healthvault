# 🫀 HealthVault — Personal Health Records

A mobile-first web app to upload, organise, and track your medical records from any source.

## Features

- **Multi-format document upload** — PDF, JPG/PNG, DOCX, XLSX, HL7, DICOM, XML, CSV, TXT and more
- **Smart auto-categorisation** — detects Discharge Reports, Lab Results, Prescriptions, Imaging from filename
- **Health timeline** — chronological view of all your records
- **Medication tracker** — active and past medications with refill alerts
- **Patient summary** — quick-glance dashboard with lab values and appointments
- **Drag & drop upload** — drag files directly onto the upload zone
- **Mobile-optimised** — designed for phone browsers first

---

## Deploy to Vercel in 5 minutes

### Prerequisites
- [Node.js 18+](https://nodejs.org) installed
- [Vercel account](https://vercel.com) (free tier is fine)
- [Vercel CLI](https://vercel.com/cli): `npm install -g vercel`

### Steps

```bash
# 1. Unzip / navigate to the project folder
cd healthvault

# 2. Install dependencies
npm install

# 3. Login to Vercel (first time only)
vercel login

# 4. Deploy!
vercel --prod
```

Vercel will give you a live URL like `https://healthvault-abc123.vercel.app` — open it on your phone.

---

## Project structure

```
healthvault/
├── api/
│   └── documents.js     ← Serverless API (upload, list, delete docs & meds)
├── public/
│   └── index.html       ← Complete frontend SPA
├── package.json
├── vercel.json          ← Routing config
└── README.md
```

---

## Adding persistent storage (recommended for production)

By default the app uses **in-memory storage** — data resets when the serverless function cold-starts. To make data permanent:

### Option A — Vercel Blob (easiest, stays on Vercel)

1. In your Vercel dashboard → Storage → Create Blob Store
2. Add environment variable: `BLOB_READ_WRITE_TOKEN`
3. In `api/documents.js`, replace the in-memory `store.documents.unshift(doc)` section with:

```js
import { put, list, del } from '@vercel/blob';

// Upload file:
const { url } = await put(file.originalname, file.buffer, { access: 'public' });
doc.url = url;

// List files:
const { blobs } = await list();

// Delete:
await del(url);
```

4. Add the Vercel Blob package: `npm install @vercel/blob`

### Option B — Vercel KV (Redis) for metadata

```bash
npm install @vercel/kv
```

```js
import { kv } from '@vercel/kv';
await kv.lpush('documents', JSON.stringify(doc));
const docs = await kv.lrange('documents', 0, -1);
```

### Option C — Supabase (Postgres + file storage)

Best for a real multi-user production app with user authentication.

---

## Supported file formats

| Format | Extension | Use case |
|--------|-----------|----------|
| PDF | `.pdf` | Discharge letters, reports, referrals |
| Images | `.jpg` `.jpeg` `.png` `.gif` `.bmp` `.tiff` `.webp` | Scanned documents, photos of prescriptions |
| Word | `.doc` `.docx` | Clinical letters |
| Excel | `.xls` `.xlsx` `.csv` | Lab data exports |
| Plain text | `.txt` | Clinical notes |
| HL7 FHIR | `.hl7` `.xml` `.json` | Electronic health record exports |
| DICOM | `.dcm` `.dicom` | Medical imaging metadata |
| CCD | `.ccd` | Continuity of care documents |

---

## Environment variables

| Variable | Required | Description |
|----------|----------|-------------|
| `BLOB_READ_WRITE_TOKEN` | Optional | Vercel Blob storage token |
| `KV_URL` | Optional | Vercel KV Redis URL |

---

## Local development

```bash
npm install
vercel dev        # runs frontend + API locally at http://localhost:3000
```

---

## Customising

- **Patient profile**: edit the `profile-header` section in `public/index.html`
- **Colour scheme**: change CSS variables in `:root { }` at the top of the HTML
- **File size limit**: change `limits: { fileSize: 50 * 1024 * 1024 }` in `api/documents.js`
- **Auto-categorisation**: improve `guessCategory()` in `api/documents.js`

---

## Security notes for production

- Add authentication (e.g. Vercel Auth, NextAuth, Clerk) before going live
- Store files in encrypted Blob storage
- Use HTTPS only (Vercel provides this automatically)
- Consider patient data regulations in your country (GDPR in UK/EU, HIPAA in US)

// api/documents.js — HealthVault serverless API (CommonJS for Vercel Node runtime)
const { v4: uuidv4 } = require('uuid');

// In-memory store — survives warm invocations, resets on cold start.
// Replace with Vercel KV / Supabase for persistence.
const store = globalThis.__hv_store ?? (globalThis.__hv_store = {
  documents: [
    { id: '1', name: 'Discharge Summary — Royal Berkshire Hospital', category: 'discharge', date: '2025-11-18', size: '1.2 MB', notes: 'Admitted for chest pain. ECG normal. Discharged with follow-up in 4 weeks.', url: null },
    { id: '2', name: 'HbA1c & Lipid Panel Results',                  category: 'lab',        date: '2026-01-07', size: '420 KB', notes: 'HbA1c 7.2%, LDL 2.8 mmol/L, eGFR 74 mL/min.', url: null },
    { id: '3', name: 'Metformin 500mg Prescription',                 category: 'prescription',date: '2026-02-20', size: '180 KB', notes: '90-day supply. Twice daily with meals.', url: null },
    { id: '4', name: 'Chest X-Ray Report',                           category: 'imaging',    date: '2026-03-14', size: '2.1 MB', notes: 'No acute cardiopulmonary process identified.', url: null }
  ],
  medications: [
    { id: 'm1', name: 'Metformin',    dose: '500mg', frequency: 'Twice daily', status: 'active', refillDue: true  },
    { id: 'm2', name: 'Ramipril',     dose: '5mg',   frequency: 'Once daily',  status: 'active', refillDue: false },
    { id: 'm3', name: 'Atorvastatin', dose: '20mg',  frequency: 'At night',    status: 'active', refillDue: false },
    { id: 'm4', name: 'Aspirin',      dose: '75mg',  frequency: 'Once daily',  status: 'past',   refillDue: false }
  ]
});

// ── CORS headers ──────────────────────────────────────────────────────────────
function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

// ── Parse multipart (no external dep beyond busboy, which ships with Node) ────
function parseMultipart(req) {
  return new Promise((resolve, reject) => {
    const busboy = require('busboy');
    const bb = busboy({ headers: req.headers, limits: { fileSize: 50 * 1024 * 1024 } });
    const fields = {};
    const files = [];
    bb.on('field', (name, val) => { fields[name] = val; });
    bb.on('file', (name, stream, info) => {
      const chunks = [];
      stream.on('data', d => chunks.push(d));
      stream.on('end', () => files.push({
        fieldname: name,
        originalname: info.filename,
        mimetype: info.mimeType,
        buffer: Buffer.concat(chunks)
      }));
    });
    bb.on('finish', () => resolve({ fields, files }));
    bb.on('error', reject);
    req.pipe(bb);
  });
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function guessCategory(filename) {
  const n = (filename || '').toLowerCase();
  if (n.includes('discharge') || n.includes('summary') || n.includes('admission')) return 'discharge';
  if (n.includes('lab') || n.includes('result') || n.includes('blood') || n.includes('hba') || n.includes('panel') || n.includes('test')) return 'lab';
  if (n.includes('rx') || n.includes('prescription') || n.includes('med') || n.includes('tablet') || n.includes('capsule') || n.includes('drug')) return 'prescription';
  if (n.includes('xray') || n.includes('x-ray') || n.includes('ct') || n.includes('mri') || n.includes('scan') || n.includes('imaging') || n.includes('dicom') || n.includes('dcm')) return 'imaging';
  return 'other';
}

function fmtSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return Math.round(bytes / 1024) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => (data += c));
    req.on('end', () => { try { resolve(JSON.parse(data || '{}')); } catch(e) { resolve({}); } });
    req.on('error', reject);
  });
}

// ── Main handler ──────────────────────────────────────────────────────────────
module.exports = async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(200).end();

  const { action, id } = req.query;

  // GET — list all documents and medications
  if (req.method === 'GET' && action === 'list') {
    return res.json({ documents: store.documents, medications: store.medications });
  }

  // POST — upload one or more files
  if (req.method === 'POST' && action === 'upload') {
    try {
      const { fields, files } = await parseMultipart(req);
      if (!files.length) return res.status(400).json({ error: 'No file received' });

      const added = files.map(file => {
        const doc = {
          id:           uuidv4(),
          name:         (file.originalname || 'Unnamed document').replace(/\.[^.]+$/, ''),
          category:     fields.category || guessCategory(file.originalname),
          date:         fields.date || new Date().toISOString().split('T')[0],
          size:         fmtSize(file.buffer.length),
          notes:        fields.notes || '',
          mimetype:     file.mimetype,
          originalname: file.originalname,
          url:          null   // ← plug in Vercel Blob URL here when ready
        };
        store.documents.unshift(doc);
        return doc;
      });

      return res.json({ success: true, documents: added });
    } catch (e) {
      console.error('Upload error:', e);
      return res.status(500).json({ error: e.message });
    }
  }

  // DELETE — remove a document
  if (req.method === 'DELETE' && action === 'delete') {
    const idx = store.documents.findIndex(d => d.id === id);
    if (idx === -1) return res.status(404).json({ error: 'Document not found' });
    store.documents.splice(idx, 1);
    return res.json({ success: true });
  }

  // POST — add medication
  if (req.method === 'POST' && action === 'add-medication') {
    const body = await readBody(req);
    if (!body.name) return res.status(400).json({ error: 'Name required' });
    const med = { id: uuidv4(), refillDue: false, ...body };
    store.medications.unshift(med);
    return res.json({ success: true, medication: med });
  }

  // DELETE — remove medication
  if (req.method === 'DELETE' && action === 'delete-medication') {
    const idx = store.medications.findIndex(m => m.id === id);
    if (idx !== -1) store.medications.splice(idx, 1);
    return res.json({ success: true });
  }

  return res.status(405).json({ error: 'Method not allowed' });
};

module.exports.config = { api: { bodyParser: false } };
